package cn.edu.xmu.javaee.productdemoaop.jpa.repository;

import cn.edu.xmu.javaee.productdemoaop.jpa.entity.OnsaleEntity;
import cn.edu.xmu.javaee.productdemoaop.jpa.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OnsaleRepository extends JpaRepository<OnsaleEntity, Long> {
}
