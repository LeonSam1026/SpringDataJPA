//School of Informatics Xiamen University, GPL-3.0 license
package cn.edu.xmu.javaee.core.validation;

import jakarta.validation.groups.Default;

public interface NewGroup extends Default {
}
